import React, { useState, useEffect } from 'react';
import { 
  Users, 
  Package, 
  TrendingUp, 
  CheckCircle, 
  Clock, 
  Search, 
  Download,
  LogOut,
  LayoutDashboard,
  ClipboardList,
  MoreVertical
} from 'lucide-react';

const AdminPanel = () => {
  const [bookings, setBookings] = useState([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');

  // Local Backend kadhun bookings fecth karne (Simulated for now)
  useEffect(() => {
    const fetchBookings = async () => {
      try {
        // Mock data - Jeva tumcha server.js run hoil teva real API vapra
        const mockData = [
          { id: "AM101", customerName: "Rahul Patil", mobile: "9823000011", service: "Courier Services", status: "Pending", date: "2024-03-20" },
          { id: "AM102", customerName: "Amit Shinde", mobile: "9977665544", service: "Transport Services", status: "Completed", date: "2024-03-19" },
          { id: "AM103", customerName: "Sagar Deshmukh", mobile: "8800991122", service: "International Shipping", status: "In Transit", date: "2024-03-18" },
          { id: "AM104", customerName: "Priya More", mobile: "7766554433", service: "Business MSME", status: "Pending", date: "2024-03-18" },
        ];
        setBookings(mockData);
        setLoading(false);
      } catch (error) {
        console.error("Error fetching bookings:", error);
        setLoading(false);
      }
    };
    fetchBookings();
  }, []);

  const stats = [
    { title: "Total Bookings", value: bookings.length, icon: ClipboardList, color: "#3b82f6" },
    { title: "Pending Orders", value: bookings.filter(b => b.status === 'Pending').length, icon: Clock, color: "#f59e0b" },
    { title: "Completed", value: bookings.filter(b => b.status === 'Completed').length, icon: CheckCircle, color: "#10b981" },
    { title: "Active Customers", value: "124", icon: Users, color: "#8b5cf6" },
  ];

  return (
    <div className="min-h-screen bg-[#f8fafc] flex">
      
      {/* 1. Sidebar (Dark Blue - Professional Look) */}
      <div className="w-64 bg-[#0f172a] text-white p-6 hidden lg:flex flex-col">
        <div className="mb-10">
          <h1 className="text-2xl font-black italic text-blue-400 leading-none">APNI MANZIL</h1>
          <p className="text-[10px] text-slate-500 uppercase tracking-widest font-bold mt-1">Admin Dashboard</p>
        </div>
        
        <nav className="space-y-2 flex-1">
          <div className="flex items-center gap-3 p-3 bg-blue-600 rounded-xl cursor-pointer shadow-lg shadow-blue-500/20">
            <LayoutDashboard size={20} /> <span className="text-sm font-bold">Dashboard Overview</span>
          </div>
          <div className="flex items-center gap-3 p-3 text-slate-400 hover:text-white hover:bg-white/5 rounded-xl transition-all cursor-pointer">
            <Package size={20} /> <span className="text-sm font-bold">All Orders</span>
          </div>
          <div className="flex items-center gap-3 p-3 text-slate-400 hover:text-white hover:bg-white/5 rounded-xl transition-all cursor-pointer">
            <Users size={20} /> <span className="text-sm font-bold">Customer List</span>
          </div>
        </nav>

        <div className="pt-6 border-t border-white/10">
          <div className="flex items-center gap-3 p-3 text-red-400 hover:bg-red-500/10 rounded-xl cursor-pointer transition-all">
            <LogOut size={20} /> <span className="text-sm font-bold">Logout</span>
          </div>
        </div>
      </div>

      {/* 2. Main Area */}
      <div className="flex-1 p-6 md:p-10 overflow-y-auto">
        
        {/* Header Area */}
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 mb-10">
          <div>
            <h2 className="text-3xl font-black text-slate-800 tracking-tight">Main Dashboard</h2>
            <p className="text-slate-500 text-sm font-medium">Aajche navin bookings ani updates ithe pahu shakata.</p>
          </div>
          <button className="flex items-center gap-2 bg-white border border-slate-200 px-5 py-2.5 rounded-xl text-sm font-bold text-slate-700 hover:bg-slate-50 transition-all shadow-sm">
            <Download size={18} /> Excel Report
          </button>
        </div>

        {/* Stats Cards */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mb-10">
          {stats.map((s, i) => (
            <div key={i} className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm hover:shadow-md transition-shadow">
              <div className="flex justify-between items-start mb-4">
                <div style={{ backgroundColor: `${s.color}15`, color: s.color }} className="p-3 rounded-2xl">
                  <s.icon size={24} />
                </div>
                <div className="text-green-500 text-[10px] font-bold bg-green-50 px-2 py-1 rounded-lg">+12%</div>
              </div>
              <h3 className="text-slate-400 text-[11px] font-black uppercase tracking-widest">{s.title}</h3>
              <p className="text-3xl font-black text-slate-800 mt-1">{s.value}</p>
            </div>
          ))}
        </div>

        {/* Bookings Table Container */}
        <div className="bg-white rounded-[2rem] border border-slate-100 shadow-sm overflow-hidden">
          
          {/* Table Toolbar */}
          <div className="p-6 border-b border-slate-50 flex flex-col md:flex-row justify-between items-center gap-4">
            <h3 className="font-black text-slate-800 text-lg">Navin Bookings</h3>
            <div className="relative w-full md:w-80">
              <Search className="absolute left-4 top-3 text-slate-400" size={18} />
              <input 
                type="text" 
                placeholder="Search by name, ID or Mobile..." 
                className="w-full pl-12 pr-4 py-3 bg-slate-50 border border-slate-200 rounded-2xl text-sm outline-none focus:ring-4 focus:ring-blue-500/10 transition-all"
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
              />
            </div>
          </div>

          {/* Actual Table */}
          <div className="overflow-x-auto">
            <table className="w-full text-left">
              <thead className="bg-slate-50/50 text-[11px] font-black text-slate-400 uppercase tracking-widest">
                <tr>
                  <th className="px-8 py-5">Order ID</th>
                  <th className="px-8 py-5">Customer Name</th>
                  <th className="px-8 py-5">Service Type</th>
                  <th className="px-8 py-5">Date</th>
                  <th className="px-8 py-5">Status</th>
                  <th className="px-8 py-5">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-50 text-sm">
                {bookings.filter(b => b.customerName.toLowerCase().includes(searchTerm.toLowerCase())).map((b) => (
                  <tr key={b.id} className="hover:bg-slate-50/50 transition-colors group">
                    <td className="px-8 py-5 font-mono text-xs text-slate-400">{b.id}</td>
                    <td className="px-8 py-5">
                      <div className="flex flex-col">
                        <span className="font-bold text-slate-700">{b.customerName}</span>
                        <span className="text-[11px] text-slate-400">{b.mobile}</span>
                      </div>
                    </td>
                    <td className="px-8 py-5">
                      <span className="bg-blue-50 text-blue-600 px-3 py-1 rounded-lg text-[10px] font-black uppercase tracking-tight">
                        {b.service}
                      </span>
                    </td>
                    <td className="px-8 py-5 text-slate-500 font-medium">{b.date}</td>
                    <td className="px-8 py-5">
                      <div className={`inline-flex items-center gap-1.5 px-3 py-1 rounded-full text-[10px] font-black uppercase ${
                        b.status === 'Completed' ? 'bg-green-50 text-green-600' : 
                        b.status === 'Pending' ? 'bg-amber-50 text-amber-600' : 'bg-blue-50 text-blue-600'
                      }`}>
                        <div className={`w-1.5 h-1.5 rounded-full ${
                          b.status === 'Completed' ? 'bg-green-600' : 
                          b.status === 'Pending' ? 'bg-amber-600' : 'bg-blue-600'
                        }`} />
                        {b.status}
                      </div>
                    </td>
                    <td className="px-8 py-5">
                      <button className="p-2 hover:bg-slate-100 rounded-lg text-slate-400 hover:text-slate-600 transition-all">
                        <MoreVertical size={18} />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {/* Empty State */}
          {bookings.length === 0 && (
            <div className="py-20 text-center">
              <Package size={48} className="mx-auto text-slate-200 mb-4" />
              <p className="text-slate-400 font-bold">Kontihi booking sapadle nahi.</p>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default AdminPanel;